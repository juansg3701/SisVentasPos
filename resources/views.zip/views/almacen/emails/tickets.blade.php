<!DOCTYPE html>
<html lang="es-ES">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>¡Ticket de pago POS!</h2>

<div>
    Mensaje enviado desde POS Controller
</div>

</body>
</html>