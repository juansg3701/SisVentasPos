<?php
$mysqli = new mysqli("localhost", "root", "", "final");